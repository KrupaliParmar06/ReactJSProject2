import './App.css';

import PersonDefaultDemo from './Components/DefaultProp'

import ArrayProps from './Components/ArrayAsProps'


import ParentSampleRenderProps from './Components/RenderPropDemo'

// import GrandParent from './Components/Live';

function App() {
  return (
    //Default Prop - Class Componet with Props
    <>
       <PersonDefaultDemo></PersonDefaultDemo>
       <PersonDefaultDemo name="Jay Patel" gender="Male" designation="Vice Director"></PersonDefaultDemo>
       <PersonDefaultDemo name="Krupali Parmar" gender="Female"></PersonDefaultDemo>
       <PersonDefaultDemo name="Aakash Panchal" gender="Male"></PersonDefaultDemo>
    

    {/* Array as Props */}
    <ArrayProps/>


     {/* Render Props */}
     <ParentSampleRenderProps/>
  </>
  );
}

export default App;
